#include <iostream>

using namespace std;

int main()
{
    int radius;
    cout << "Enter the radius of the circle: ";
	cin >> radius;
    cout << (radius * radius) * 3.14;
	
	return 0;
}