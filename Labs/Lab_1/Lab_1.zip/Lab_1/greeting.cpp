#include <iostream>

using namespace std;

int main()
{
	string name;
	cin >> name;
    cout << "Hi, my name is " << name << "!";
	return 0;
}